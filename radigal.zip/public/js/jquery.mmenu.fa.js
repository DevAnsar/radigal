jQuery.mmenu.i18n({Menu:"منو"},"fa");
jQuery.mmenu.i18n({"Close menu":"بستن منو","Close submenu":"بستن زیرمنو","Open submenu":"بازکردن زیرمنو","Toggle submenu":"سوییچ زیرمنو"},"fa");
jQuery.mmenu.i18n({Search:"جستجو","No results found.":"نتیجه‌ای یافت نشد.",cancel:"انصراف"},"fa");