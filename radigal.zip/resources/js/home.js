window.$=window.jQuery=require('./home/jquery-3.3.1');
require('./home/bootstrap');
require('./home/custom-js');
// require('./home/jquery.mmenu.all');
// require('./home/jquery.mmenu.fa');
require('./home/swiper.min');