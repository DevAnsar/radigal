<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Column1footer extends Model
{
    protected $fillable=[
        'title',
        'page_id'
    ];
}
