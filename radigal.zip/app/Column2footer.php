<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Column2footer extends Model
{
    protected $fillable=[
        'title',
        'url'
    ];
}
