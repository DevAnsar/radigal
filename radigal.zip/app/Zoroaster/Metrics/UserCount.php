<?php

namespace App\Zoroaster\Metrics;

use App\User;
use Illuminate\Http\Request;
use KarimQaderi\Zoroaster\Metrics\Value;

class UserCount extends Value
{

    public $label ="تعداد کاربرا";

    /**
     * Calculate the value of the metric.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return mixed
     */
    public function calculate(Request $request)
    {
        return $this->count($request, User::Class);
    }

    /**
     * Get the ranges available for the metric.
     *
     * @return array
     */
    public function ranges()
    {
        return [
            30 => '30 Days',
            60 => '60 Days',
            365 => '365 Days',
            'MTD' => 'Month To Date',
            'QTD' => 'Quarter To Date',
            'YTD' => 'Year To Date',
        ];
    }


}
