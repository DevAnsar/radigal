<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SendStatus extends Model
{
    protected $fillable=[
        'title',
    ];
}
